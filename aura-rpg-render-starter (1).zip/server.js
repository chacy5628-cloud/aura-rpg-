'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PORT = Number(process.env.PORT || 3000);
const OWNER_ID = process.env.OWNER_ID || '제작자';
const OWNER_PASSWORD = process.env.OWNER_PASSWORD;
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data.json');
let db = { users: {}, config: {version:'1.0.0', notice:'AURA RPG에 오신 것을 환영합니다!', xpMultiplier:1, enemyHpMultiplier:1, lockUntil:0}, events:[] };
try { db = {...db, ...JSON.parse(fs.readFileSync(DB_FILE,'utf8'))}; } catch {}
const sessions = new Map();
const subscribers = new Set();
function save(){ try { fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2), {mode:0o600}); } catch(e){ console.error('Storage warning:',e.message); }}
function send(res,status,obj){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj));}
function readJSON(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>20000){reject(new Error('요청이 너무 큽니다.'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'))}catch{reject(new Error('잘못된 JSON'))}});req.on('error',reject);});}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){return {salt,hash:crypto.scryptSync(password,salt,64).toString('hex')};}
function checkPassword(password,stored){if(!stored?.salt||!stored?.hash)return false;const h=crypto.scryptSync(password,stored.salt,64);const expected=Buffer.from(stored.hash,'hex');return h.length===expected.length&&crypto.timingSafeEqual(h,expected);}
function user(req){const token=(req.headers.authorization||'').replace(/^Bearer /,'');const s=sessions.get(token);if(!s)return null;return db.users[s.id]||null;}
function safeUser(u){return {id:u.id,role:u.role,level:u.level,xp:u.xp,coins:u.coins,zone:u.zone,weapon:u.weapon,skills:u.skills||{hp:0,sprint:0}};}
function broadcast(type,data){const msg=`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;for(const res of subscribers){try{res.write(msg)}catch{subscribers.delete(res)}}}
function config(){return {...db.config, locked:Date.now()<db.config.lockUntil};}
function leaderboard(){return Object.values(db.users).map(safeUser).sort((a,b)=>b.level-a.level||b.xp-a.xp).slice(0,15);}
function levelXp(level){return Math.floor(70*Math.pow(level,1.42));}
function updated(){save();broadcast('config',config());}
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png'};
const requests=new Map();
function throttle(req){const ip=req.socket.remoteAddress||'unknown',now=Date.now(),r=requests.get(ip)||{n:0,reset:now+60000};if(now>r.reset){r.n=0;r.reset=now+60000;}r.n++;requests.set(ip,r);return r.n>200;}
const server=http.createServer(async(req,res)=>{
 try {
  const url=new URL(req.url, 'http://localhost');const p=url.pathname;
  if(throttle(req))return send(res,429,{error:'잠시 후 다시 시도하세요.'});
  if(p==='/api/events'&&req.method==='GET'){
   res.writeHead(200,{'content-type':'text/event-stream; charset=utf-8','cache-control':'no-cache','connection':'keep-alive'});res.write(`event: config\ndata: ${JSON.stringify(config())}\n\n`);subscribers.add(res);req.on('close',()=>subscribers.delete(res));return;
  }
  if(p==='/api/config'&&req.method==='GET')return send(res,200,{config:config(),leaderboard:leaderboard()});
  if(p==='/api/signup'&&req.method==='POST'){
   const b=await readJSON(req),id=String(b.id||'').trim(),pwd=String(b.password||'');
   if(id.length<2||id.length>24||pwd.length<8||pwd.length>128)return send(res,400,{error:'아이디 2~24자, 비밀번호 8~128자를 사용하세요.'});
   if(id===OWNER_ID||db.users[id])return send(res,409,{error:'사용할 수 없는 아이디입니다.'});
   const u={id,role:'player',...hashPassword(pwd),level:1,xp:0,coins:100,zone:1,weapon:'검',skills:{hp:0,sprint:0}};db.users[id]=u;save();return login(u,res);
  }
  if(p==='/api/login'&&req.method==='POST'){
   const b=await readJSON(req),id=String(b.id||'').trim(),pwd=String(b.password||'');
   let u=db.users[id];
   if(id===OWNER_ID&&OWNER_PASSWORD&&pwd===OWNER_PASSWORD){
    if(!u){u={id,role:'owner',...hashPassword(OWNER_PASSWORD),level:1,xp:0,coins:1000,zone:1,weapon:'검',skills:{hp:0,sprint:0}};db.users[id]=u;save();}
    else if(u.role==='owner'&&!checkPassword(OWNER_PASSWORD,u)){Object.assign(u,hashPassword(OWNER_PASSWORD));save();}
   }
   if(!u||!checkPassword(pwd,u))return send(res,401,{error:'아이디 또는 비밀번호가 틀립니다.'});
   return login(u,res);
  }
  if(p==='/api/me'&&req.method==='GET'){const u=user(req);return u?send(res,200,{user:safeUser(u)}):send(res,401,{error:'로그인 필요'});}
  if(p==='/api/logout'&&req.method==='POST'){const token=(req.headers.authorization||'').replace(/^Bearer /,'');sessions.delete(token);return send(res,200,{ok:true});}
  if(p.startsWith('/api/')){
   const u=user(req);if(!u)return send(res,401,{error:'로그인 필요'});
   if(p==='/api/admin'&&req.method==='POST'){
    if(u.role!=='owner')return send(res,403,{error:'제작자 전용입니다.'});
    const b=await readJSON(req);const next={...db.config};
    if(b.notice!==undefined)next.notice=String(b.notice).slice(0,240);
    if(b.version!==undefined)next.version=String(b.version).slice(0,24);
    if(b.xpMultiplier!==undefined)next.xpMultiplier=Math.max(0.5,Math.min(5,Number(b.xpMultiplier)||1));
    if(b.enemyHpMultiplier!==undefined)next.enemyHpMultiplier=Math.max(0.5,Math.min(5,Number(b.enemyHpMultiplier)||1));
    if(b.lockMinutes!==undefined)next.lockUntil=Date.now()+Math.max(0,Math.min(120,Number(b.lockMinutes)||0))*60000;
    db.config=next;db.events.push({at:Date.now(),by:u.id,config:next});db.events=db.events.slice(-100);updated();return send(res,200,{config:config()});
   }
   if(Date.now()<db.config.lockUntil&&u.role!=='owner')return send(res,423,{error:'제작자가 잠시 서버를 잠갔습니다.'});
   if(p==='/api/action'&&req.method==='POST'){
    const b=await readJSON(req),action=String(b.action||'');
    if(action==='fight'){
     const isBoss=Boolean(b.boss),gain=Math.floor((isBoss?90:18)*db.config.xpMultiplier),coin=isBoss?70:12;
     // This is a demo progression endpoint. Production multiplayer combat needs authoritative world state.
     u.xp+=gain;u.coins+=coin;let levels=0;while(u.xp>=levelXp(u.level)&&levels<20){u.xp-=levelXp(u.level);u.level++;levels++;}
     if(isBoss&&u.zone<5)u.zone++;
     save();broadcast('leaderboard',leaderboard());return send(res,200,{user:safeUser(u),gain,coin,levels});
    }
    if(action==='weapon'){
     const w=String(b.weapon||'');const prices={'검':0,'활':150,'에너지총':320};if(!(w in prices))return send(res,400,{error:'없는 무기입니다.'});if(u.coins<prices[w])return send(res,400,{error:'골드가 부족합니다.'});u.coins-=prices[w];u.weapon=w;save();return send(res,200,{user:safeUser(u)});
    }
    if(action==='skill'){
     const skill=String(b.skill||'');if(!['hp','sprint'].includes(skill))return send(res,400,{error:'없는 스킬입니다.'});const cost=100*(1+(u.skills[skill]||0));if(u.coins<cost)return send(res,400,{error:'골드가 부족합니다.'});u.coins-=cost;u.skills[skill]++;save();return send(res,200,{user:safeUser(u)});
    }
    return send(res,400,{error:'알 수 없는 행동입니다.'});
   }
   return send(res,404,{error:'경로 없음'});
  }
  if(req.method!=='GET')return send(res,405,{error:'허용되지 않은 요청'});
  const file=p==='/'?'/index.html':p;
  const target=path.resolve(__dirname,'public', '.'+file);
  if(!target.startsWith(path.join(__dirname,'public')+path.sep))return send(res,403,{error:'접근 불가'});
  fs.readFile(target,(err,buf)=>{if(err){res.writeHead(404);res.end('Not found');return;}res.writeHead(200,{'content-type':MIME[path.extname(target)]||'application/octet-stream','x-content-type-options':'nosniff'});res.end(buf)});
 }catch(e){console.error(e);if(!res.headersSent)send(res,500,{error:'서버 오류'});}
});
function login(u,res){const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{id:u.id});send(res,200,{token,user:safeUser(u)});}
server.listen(PORT,'0.0.0.0',()=>console.log(`AURA RPG running on port ${PORT}`));
