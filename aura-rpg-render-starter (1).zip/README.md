# AURA RPG · Render 배포 체험판

학교 계정 비밀번호를 요구하지 않는 간단한 아이디/비밀번호 가입, 5개 지역, 레벨과 랭킹, 무기와 스킬, 제작자 실시간 공지·배율·서버 잠금 기능이 포함된 **초기 체험판**입니다. 본격적인 3D MMORPG가 아니며 실제 다중 사용자 전투 시스템은 아직 없습니다.

## GitHub 업로드
1. GitHub의 `aura-rpg` 저장소로 이동해 **Add file → Upload files**를 누릅니다.
2. 압축파일을 해제하고 `server.js`, `package.json`, `render.yaml`, `.gitignore`, `README.md`, `public/index.html` 파일을 업로드합니다. 반드시 `public` 폴더 구조가 유지되어야 합니다. ZIP 자체를 올리면 실행되지 않습니다.
3. **Commit changes**를 누릅니다.

## Render 배포
1. Render 대시보드에서 **New → Web Service → Git Provider**를 선택하고 GitHub 저장소 `aura-rpg`를 연결합니다.
2. 서비스 이름은 원하는 이름으로 입력합니다. Runtime은 **Node**, Build Command는 `npm install`, Start Command는 `npm start`, 무료 서비스가 제공되면 Free를 선택합니다.
3. **Environment**(환경 변수)에 다음을 추가합니다.
   - `OWNER_ID`: `제작자`
   - `OWNER_PASSWORD`: 제작자만 아는 **새 비밀번호** (절대 GitHub 코드에 넣지 마세요)
   - `SESSION_SECRET`: 긴 임의 비밀 문자열 (Render의 Generate 기능 이용 권장)
4. **Create Web Service** 후 배포 로그에서 실행 완료를 확인합니다. Render가 실제 `.onrender.com` URL을 발급합니다. URL은 미리 만들어낼 수 없습니다.
5. Render `render.yaml`의 Blueprints 기능을 사용한다면 `OWNER_PASSWORD`를 설정해 달라는 프롬프트에서 새 비밀번호를 입력합니다.

## 중요한 제한
- **데이터 보존**: 현재 파일 `data.json`에 저장하는 체험판입니다. Render의 임시 파일 시스템은 배포/재시작 시 없어질 수 있습니다. 실제 운영 전에는 PostgreSQL 같은 영구 데이터베이스에 계정과 진행도를 저장하도록 전환해야 합니다.
- **보안**: 비밀번호는 scrypt 해시로 저장됩니다. 제작자 초기 비밀번호는 환경 변수에만 넣습니다. 기존에 채팅에 입력했던 비밀번호는 사용하지 말고 새 비밀번호를 생성하세요.
- **운영 안정성**: 로그인 세션은 서버 메모리에 저장되어 서버 재시작 시 로그아웃될 수 있습니다. 공격/보스 버튼은 데모 기능이며 악용 방지, 속도 제한, 완전한 서버 권한 검증을 갖춘 실제 멀티플레이 전투 서버는 아닙니다.
- **실시간 변경**: 공지/배율/잠금만 SSE로 실시간 반영됩니다. 코드·맵·무기 추가는 GitHub 변경 후 Render 재배포가 필요합니다.
- 가입에 실제 학교 계정이나 학교 비밀번호는 사용하지 마세요.
